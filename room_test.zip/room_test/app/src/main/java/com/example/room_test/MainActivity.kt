package com.example.room_test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.logging.Logger

class MainActivity : AppCompatActivity() {
    lateinit var personDao:PersonDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        personDao = PersonDatabase.getInstance(application).personDao()
        val save_btn = findViewById<Button>(R.id.save_btn)
        save_btn.setOnClickListener { save() }
        val view_btn = findViewById<Button>(R.id.view_btn)
        view_btn.setOnClickListener { view_all() }
    }

    fun view_all(){
        startActivity(Intent(this, ViewActivity::class.java))
    }

    fun save(){
        //get input info
        val name = findViewById<EditText>(R.id.name).text.toString()
        val age = findViewById<EditText>(R.id.age).text.toString().toInt()
        val hometown = findViewById<EditText>(R.id.hometown).text.toString()

        val person = Person(name=name, age=age, hometown=hometown)
        // TODO
        // insert person to the Database

        findViewById<EditText>(R.id.name).setText("")
        findViewById<EditText>(R.id.age).setText("")
        findViewById<EditText>(R.id.hometown).setText("")
    }
}