package com.example.room_test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)
        // TODO
        // Get the LinearLayout R.id.person_list_layout
        // Get all entries from the database
        // For each entry, add a TextView to the LinearLayout

        findViewById<Button>(R.id.add_btn).setOnClickListener { add() }
    }
    fun add(){
        val intent: Intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}