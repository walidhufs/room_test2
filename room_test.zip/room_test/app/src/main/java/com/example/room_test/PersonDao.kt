package com.example.room_test

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface PersonDao {
    // TODO
    // add insert, getAll functions
}